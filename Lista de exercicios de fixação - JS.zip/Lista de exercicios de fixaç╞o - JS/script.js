    function exercicio1() {
      let A = Number(document.getElementById("a1").value);
      let B = Number(document.getElementById("b1").value);
      let C = Number(document.getElementById("c1").value);
      let soma = A + B;
      let msg = `Soma: ${soma}. `;
      msg += soma < C ? "A soma é menor que C." : "A soma não é menor que C.";
      document.getElementById("saida1").innerText = msg;
    }

    function exercicio2() {
      let num = Number(document.getElementById("num2").value);
      let msg = num % 2 === 0 ? "Par" : "Ímpar";
      msg += num >= 0 ? " e Positivo" : " e Negativo";
      document.getElementById("saida2").innerText = msg;
    }

    function exercicio3() {
      let A = Number(document.getElementById("a3").value);
      let B = Number(document.getElementById("b3").value);
      let C = A === B ? A + B : A * B;
      document.getElementById("saida3").innerText = "Resultado: " + C;
    }

    function exercicio4() {
      let num = Number(document.getElementById("num4").value);
      document.getElementById("saida4").innerText = 
        `Antecessor: ${num - 1}, Sucessor: ${num + 1}`;
    }

    function exercicio5() {
      let sal = Number(document.getElementById("sal5").value);
      let qtd = sal / 1293.20;
      document.getElementById("saida5").innerText = 
        `Ganha ${qtd.toFixed(2)} salários mínimos`;
    }

    function exercicio6() {
      let val = Number(document.getElementById("val6").value);
      let reaj = val * 1.05;
      document.getElementById("saida6").innerText = 
        `Valor reajustado: R$ ${reaj.toFixed(2)}`;
    }

    function exercicio7() {
      let b1 = document.getElementById("bool1").value === "true";
      let b2 = document.getElementById("bool2").value === "true";
      let msg = "";
      if (b1 && b2) msg = "Ambos Verdadeiros";
      else if (!b1 && !b2) msg = "Ambos Falsos";
      else msg = "Um verdadeiro e outro falso";
      document.getElementById("saida7").innerText = msg;
    }

    function exercicio8() {
      let a = Number(document.getElementById("a8").value);
      let b = Number(document.getElementById("b8").value);
      let c = Number(document.getElementById("c8").value);
      let arr = [a,b,c].sort((x,y) => y-x);
      document.getElementById("saida8").innerText = arr.join(", ");
    }

    function exercicio9() {
      let n1 = Number(document.getElementById("n91").value);
      let n2 = Number(document.getElementById("n92").value);
      let n3 = Number(document.getElementById("n93").value);
      let media = (n1+n2+n3)/3;
      document.getElementById("saida9").innerText = "Média: " + media.toFixed(2);
    }

    function exercicio10() {
      let nome = document.getElementById("nome10").value;
      let n1 = Number(document.getElementById("n101").value);
      let n2 = Number(document.getElementById("n102").value);
      let n3 = Number(document.getElementById("n103").value);
      let n4 = Number(document.getElementById("n104").value);
      let media = (n1+n2+n3+n4)/4;
      let status = media >= 7 ? "Aprovado ✅" : "Reprovado ❌";
      document.getElementById("saida10").innerText = 
        `${nome} - Média: ${media.toFixed(2)} - ${status}`;
    }

    function exercicio11() {
      let val = Number(document.getElementById("val11").value);
      let cod = Number(document.getElementById("cod11").value);
      let final;
      switch(cod) {
        case 1: final = val*0.85; break;
        case 2: final = val*0.90; break;
        case 3: final = val; break;
        case 4: final = val*1.10; break;
        default: final = val;
      }
      document.getElementById("saida11").innerText = 
        "Valor final: R$ " + final.toFixed(2);
    }