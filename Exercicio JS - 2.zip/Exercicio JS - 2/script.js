function analisar() {
  const input = document.getElementById("numero");
  const valor = parseFloat(input.value);
  const result = document.getElementById("resultado");

  if (isNaN(valor)) {
    result.innerHTML = "<li>⚠️ Por favor, digite um número válido.</li>";
    return;
  }

  const absoluto = Math.abs(valor);
  const inteiro = Math.trunc(valor);
  const arredondado = Math.round(valor);
  const raizQuadrada = Math.sqrt(valor);
  const raizCubica = Math.cbrt(valor);
  const quadrado = Math.pow(valor, 2);
  const cubo = Math.pow(valor, 3);

  result.innerHTML = `
    <li>O número digitado é <strong>${valor}</strong></li>
    <li>O seu valor absoluto é <strong>${absoluto}</strong></li>
    <li>A sua parte inteira é <strong>${inteiro}</strong></li>
    <li>O valor inteiro mais próximo é <strong>${arredondado}</strong></li>
    <li>A sua raiz quadrada é <strong>${raizQuadrada}</strong></li>
    <li>A sua raiz cúbica é <strong>${raizCubica}</strong></li>
    <li>O valor de ${valor}<sup>2</sup> é <strong>${quadrado}</strong></li>
    <li>O valor de ${valor}<sup>3</sup> é <strong>${cubo}</strong></li>
  `;
}